import bpy,math
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent
if ROOT.name=='previs_v3':ROOT=ROOT.parent
BASE=ROOT/'source'/'base_scene_v2.blend'
if not BASE.exists():BASE=Path('/workspace/outputs/broken_blade_previs_v2.blend')
bpy.ops.wm.open_mainfile(filepath=str(BASE))
s=bpy.context.scene
OUT=ROOT/'previs_v3'
(OUT/'frames').mkdir(parents=True,exist_ok=True)
def segment(o,a,b,r,frame=None):
 a,b=Vector(a),Vector(b);o.location=(a+b)/2;o.rotation_mode='QUATERNION';o.rotation_quaternion=(b-a).to_track_quat('Z','Y');o.scale=(r,r,(b-a).length/2)
 if frame:
  for p in ['location','rotation_quaternion','scale']:o.keyframe_insert(p,frame=frame)

def ktransform(o,f):
 for p in ['location','rotation_euler','scale']:o.keyframe_insert(p,frame=f)

def actor(name,f,x,y,face,lean=0,crouch=0,arms=None,stride=0,bladeangle=0,visible=True,yaw_override=None,lift=0,sheathed=False,blade_target=None):
 parts=actors[name]
 yaw=(.45 if name=='A' else -.29 if name=='B' else 0) if yaw_override is None else yaw_override
 def P(p):
  u,v=face*p[0],p[1]
  return Vector((x+u*math.cos(yaw)-v*math.sin(yaw),y+u*math.sin(yaw)+v*math.cos(yaw),p[2]+lift))
 hip=Vector((0,0,1.03-crouch));shoulder=Vector((lean,0,1.65-crouch));head=shoulder+Vector((lean*.15,0,.29))
 if name=='Main' and lean<-.15:head.x+=.35
 segment(parts['neck'],P(shoulder),P(head-Vector((0,0,.17))),.10,f)
 segment(parts['torso'],P(hip),P(shoulder),.24,f)
 parts['head'].location=P(head);parts['head'].scale=(.19,.18,.23);ktransform(parts['head'],f)
 parts['belt'].location=P(hip);parts['belt'].scale=(.25,.19,.19);ktransform(parts['belt'],f)
 if arms is None:arms=[(.42,-.23,1.42),(.72,-.2,1.42),(.22,.23,1.28),(.45,.2,1.15)]
 for side,el,wr,dy in [('L',arms[0],arms[1],-.23),('R',arms[2],arms[3],.23)]:
  segment(parts['upper'+side],P(shoulder+Vector((0,dy,0))),P(el),.085,f)
  segment(parts['fore'+side],P(el),P(wr),.075,f)
 for side,dy,s in [('L',-.13,stride),('R',.13,-stride)]:
  knee=(s*.3+lean*.4,dy,.58-crouch*.45);foot=(s*.55-.12,dy,.12)
  segment(parts['thigh'+side],P(hip+Vector((0,dy,0))),P(knee),.105,f)
  segment(parts['shin'+side],P(knee),P(foot),.09,f)
  o=parts['foot'+side];o.location=P((foot[0]+.1,dy,.08));o.scale=(.19,.105,.08);o.rotation_euler.z=yaw;ktransform(o,f)
 wrist=P(arms[1]);length=.68 if name=='Messenger' else .85
 direction=Vector((face*math.cos(bladeangle)*math.cos(yaw),face*math.cos(bladeangle)*math.sin(yaw),math.sin(bladeangle)))
 tip=wrist+direction*length
 if blade_target is not None:tip=Vector(blade_target);length=(tip-wrist).length;direction=(tip-wrist).normalized()
 if sheathed:
  wrist=P((.04,-.33,1.01));tip=P((-.12,-.33,.37));length=(tip-wrist).length;direction=(tip-wrist).normalized()
 if 'sheath' in parts:
  o=parts['sheath'];a=P((.03,-.35,.98));b=P((-.13,-.35,.34));segment(o,a,b,.048,f)
 o=parts['blade'];o.location=(wrist+tip)/2;o.rotation_mode='QUATERNION';o.rotation_quaternion=direction.to_track_quat('Z','Y');o.scale=(.038,.018,length/2)
 for prop in ['location','rotation_quaternion','scale']:o.keyframe_insert(prop,frame=f)
 o=parts['guard'];o.location=wrist;o.scale=(.035,.13,.035);ktransform(o,f)
 if 'hat' in parts:o=parts['hat'];o.location=P(head+Vector((0,0,.2)));ktransform(o,f)
 else:
  o=parts['headband'];o.location=P(head+Vector((0,0,.1)));o.scale=(.195,.185,.04);ktransform(o,f)
 for o in parts.values():
  o.hide_render=(not visible) or (o==parts.get('sheath') and not sheathed);o.keyframe_insert('hide_render',frame=f)

actors={}
for n in ['Messenger','Main','A','B']:
 parts={o.name[len(n)+1:]:o for o in bpy.data.objects if o.name.startswith(n+'_')}
 parts['belt']=parts.pop('hips');actors[n]=parts
for o in bpy.data.objects:
 if o.animation_data and o.animation_data.action:
  for fc in o.animation_data.action.fcurves:
   for i in range(len(fc.keyframe_points)-1,-1,-1):
    if fc.keyframe_points[i].co.x>=313:fc.keyframe_points.remove(fc.keyframe_points[i])
for m in list(s.timeline_markers):
 if m.frame>=313:s.timeline_markers.remove(m)
startarms=[(.38,-.25,1.35),(.73,.4,1.36),(.05,.25,1.3),(-.12,.25,1.15)]
endarms=[(.16,-.3,1.18),(.30,-.32,1.03),(.10,.23,1.18),(.23,.23,1.0)]
for f in range(313,457):
 t=max(0,min(1,(f-313)/23));ease=t*t*(3-2*t)
 settle=max(0,min(1,(f-313)/18));settle=settle*settle*(3-2*settle)
 arms=[tuple(Vector(a).lerp(Vector(b),settle)) for a,b in zip(startarms,endarms)]
 breath=.018*math.sin(math.pi*(f-337)/30) if 337<=f<=367 else 0
 actor('Messenger',f,-.8,-.6*ease,1,0,0,arms,0,.1+(-1.0)*settle)
 # Visible inhale and release, followed by a still hold.
 for part,weight in [('torso',1),('neck',1),('head',1),('headband',1),('upperL',.5),('upperR',.5)]:
  o=actors['Messenger'][part];o.location.z+=breath*weight;o.keyframe_insert('location',frame=f)
 if f>=409:
  o=actors['Messenger']['headband'];o.location.z+=.06;o.keyframe_insert('location',frame=f)
 o=actors['Messenger']['torso'];o.scale.x*=1+breath*1.4;o.scale.y*=1+breath*1.4;o.keyframe_insert('scale',frame=f)
 actor('Main',f,2.0,1.55,-1,-.4,.6,bladeangle=0)
 reveal=max(0,min(1,(f-439)/17))
 for n,x,y,yend in [('A',-4,-2.3,-2.1),('B',-4.8,.8,.6)]:
  actor(n,f,x,y+(yend-y)*reveal,1,arms=[(.25,-.23,1.18),(.50,-.2,1.1),(.2,.23,1.2),(.35,.25,1.0)],bladeangle=-.6,visible=f>=439)

def mat(n,c):
 m=bpy.data.materials.new(n);m.diffuse_color=c;return m
red=mat('Blood_Simple',(0.65,.005,.008,1));white=mat('Eye_White',(.86,.88,.88,1));dark=mat('Eye_Dark',(.018,.025,.03,1))
def sphere(n,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(m);return o

def visibility(o,first,last=456):
 for f,hidden in [(1,True),(first-1,True),(first,False),(last,False),(last+1,True)]:
  o.hide_render=hidden;o.keyframe_insert('hide_render',frame=f)

s.frame_set(385)
blade=actors['Messenger']['blade'];direction=blade.rotation_quaternion@Vector((0,0,1));tip=blade.location+direction*blade.scale.z
# Plain red geometry for a bead at the tip and two independently falling drops.
bead=sphere('Blood_Tip_Bead',tip-Vector((0,0,.024)),(.024,.024,.036),red);visibility(bead,385,408)
for i,start in enumerate([389,400]):
 o=sphere('Blood_Drop_'+str(i),tip-Vector((0,0,.055)),(.023,.023,.034),red)
 for f,z,scale in [(start,tip.z-.055,(.023,.023,.034)),(start+6,.25,(.020,.020,.038)),(start+10,.035,(.03,.03,.02))]:
  o.location=(tip.x,tip.y,z);o.scale=scale;ktransform(o,f)
 visibility(o,start,start+10)
# Red surface mark on the visible outer blade face, without simulations.
bpy.ops.mesh.primitive_cube_add();stain=bpy.context.object;stain.name='Blood_Blade_Mark';stain.data.materials.append(red)
stain.location=blade.location+direction*.17+Vector((0,-.021,0));stain.rotation_mode='QUATERNION';stain.rotation_quaternion=blade.rotation_quaternion;stain.scale=(.027,.002,.11);visibility(stain,385)
# Only schematic eyes for the newly requested close-up; no realistic face details.
for side,y in [('L',-.685),('R',-.515)]:
 o=sphere('Eye_White_'+side,(-.625,y,1.995),(.023,.061,.031),white);visibility(o,409)
 o=sphere('Eye_Pupil_'+side,(-.602,y,1.995),(.008,.018,.022),dark);visibility(o,409)
 bpy.ops.mesh.primitive_cube_add(location=(-.6,y,2.04));o=bpy.context.object;o.name='Eye_Brow_'+side;o.scale=(.010,.062,.008);o.rotation_euler.x=.14 if side=='L' else -.14;o.data.materials.append(dark);visibility(o,409)

def camera(name,first,last,p1,t1,p2=None,t2=None,lens=48):
 bpy.ops.object.camera_add();o=bpy.context.object;o.name=name;o.data.lens=lens
 for f,p,t in [(first,p1,t1),(last,p2 or p1,t2 or t1)]:
  o.location=p;o.rotation_euler=(Vector(t)-o.location).to_track_quat('-Z','Y').to_euler();ktransform(o,f)
 s.timeline_markers.new(name,frame=first).camera=o;return o
camera('08_SETTLE_BREATHE_HOLD',313,384,(-2,-4.8,1.8),(-.8,-.3,1.15),(-2,-5.1,1.8),(-.8,-.6,1.15),lens=58)
camera('09A_BLOOD_DETAIL',385,408,(1.3,-2.2,.77),tip,(1.22,-2.15,.75),tip,lens=90)
camera('09B_EYES_CLOSEUP',409,426,(.28,-.6,2.0),(-.625,-.6,2.0),lens=85)
cam=camera('09C_EYES_AND_REAR_AMBUSH',427,447,(.28,-.6,2.0),(-.625,-.6,2.0),(1.8,-.6,1.99),(-.8,-.6,1.84),lens=85)
for f,l in [(427,85),(447,47),(456,47)]:cam.data.lens=l;cam.data.keyframe_insert('lens',frame=f)
for p in ['location','rotation_euler']:cam.keyframe_insert(p,frame=456)
for o in bpy.data.objects:
 if o.animation_data and o.animation_data.action:
  for fc in o.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='CONSTANT' if fc.data_path=='hide_render' else 'LINEAR'
 if o.type=='CAMERA' and o.data.animation_data:
  for fc in o.data.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
s.frame_start=1;s.frame_end=456;s.frame_set(1);s.render.filepath=str(OUT/'frames'/'frame_')
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'broken_blade_previs_v3.blend'))
import sys
if '--' in sys.argv and 'preview' in sys.argv:
 for f in [320,345,378,393,405,417,442,453]:
  s.frame_set(f);s.render.filepath=str(OUT/f'preview_{f}.png');bpy.ops.render.render(write_still=True)

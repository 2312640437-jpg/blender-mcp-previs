import bpy, math, random
from mathutils import Vector
from pathlib import Path
OUT=Path('/workspace/outputs/previs_v2')
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene
scene.render.engine='BLENDER_WORKBENCH'
scene.display.shading.light='STUDIO'
scene.display.shading.studiolight_rotate_z=0.45
scene.display.shading.color_type='MATERIAL'
scene.display.shading.show_shadows=True
scene.display.shading.show_cavity=True
scene.display.shading.cavity_type='BOTH'
scene.display.shading.background_type='WORLD'
scene.world=bpy.data.worlds.new('PrevisWorld')
scene.world.color=(0.11,0.13,0.16)
scene.display.render_aa='FXAA'
scene.render.resolution_x=1920; scene.render.resolution_y=1080; scene.render.resolution_percentage=100
scene.render.fps=24; scene.frame_start=1; scene.frame_end=360
scene.render.image_settings.file_format='PNG'
scene.render.filepath=str(OUT/'frames'/'frame_')
scene.view_settings.view_transform='Standard'
colors={'Messenger':(1,.32,.045,1),'Main':(.045,.16,.42,1),'A':(.5,.12,.7,1),'B':(.035,.65,.65,1),'Ground':(.72,.74,.76,1),'Bamboo':(.53,.59,.54,1),'Metal':(.8,.83,.86,1),'Dark':(.15,.18,.21,1)}
mats={}
for name,col in colors.items():
 m=bpy.data.materials.new(name);m.diffuse_color=col;mats[name]=m

def mesh(name,typ,mat,**kw):
 if typ=='sphere': bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=6,**kw)
 elif typ=='cylinder': bpy.ops.mesh.primitive_cylinder_add(vertices=10,**kw)
 elif typ=='cone': bpy.ops.mesh.primitive_cone_add(vertices=8,**kw)
 else: bpy.ops.mesh.primitive_cube_add(**kw)
 o=bpy.context.object;o.name=name;o.data.materials.append(mats[mat]);return o

def segment(o,a,b,r,frame=None):
 a,b=Vector(a),Vector(b);o.location=(a+b)/2;o.rotation_mode='QUATERNION';o.rotation_quaternion=(b-a).to_track_quat('Z','Y');o.scale=(r,r,(b-a).length/2)
 if frame:
  for p in ['location','rotation_quaternion','scale']:o.keyframe_insert(p,frame=frame)

ground=mesh('Ground','cube','Ground',location=(0,2,-.16));ground.scale=(18,18,.15)
random.seed(19)
# Clear central fight corridor; only selected impact bamboo occupies the action plane.
for i in range(65):
 x=random.uniform(-10,10);y=random.uniform(2.5,11)
 if (-3.6<x<2.5 and y<4.5) or (x<-2 and abs(y)<3): y+=5
 h=random.uniform(5,8);r=random.uniform(.075,.14)
 o=mesh('Bamboo_%02d'%i,'cylinder','Bamboo',location=(x,y,h/2));o.scale=(r,r,h/2)
 for z in [1,2,3,4,5,6]:
  if z<h:
   o=mesh('Node_%02d_%d'%(i,z),'cylinder','Bamboo',location=(x,y,z));o.scale=(r*1.13,r*1.13,.025)
for name,x,y in [('Cover',-1.85,.62),('Dodge',-1.8,-1.05),('Impact',2.43,.27)]:
 o=mesh(name+'_Bamboo','cylinder','Bamboo',location=(x,y,3));o.scale=(.16,.16,3)
 for z in range(1,6):
  o=mesh(name+'_Node_'+str(z),'cylinder','Bamboo',location=(x,y,z));o.scale=(.18,.18,.035)
for i in range(24):
 x=-3.2-(i//6)*1.8;y=-4.4+(i%6)*1.6
 if (x>-4 and -2.7<y<1.8) or min(math.hypot(x+4,y+1.8),math.hypot(x+4.8,y-.6))<1:continue
 o=mesh('RearBamboo_%02d'%i,'cylinder','Bamboo',location=(x,y,3.3));o.scale=(.11,.11,3.3)
 for z in range(1,7):
  o=mesh('RearNode_%02d_%d'%(i,z),'cylinder','Bamboo',location=(x,y,z));o.scale=(.125,.125,.025)
actors={}
for name in ['Messenger','Main','A','B']:
 parts={}
 for part in ['torso','neck','upperL','foreL','upperR','foreR','thighL','shinL','thighR','shinR']:
  parts[part]=mesh(name+'_'+part,'cylinder',name)
 parts['head']=mesh(name+'_head','sphere',name)
 parts['belt']=mesh(name+'_hips','sphere',name)
 for side in ['L','R']:parts['foot'+side]=mesh(name+'_foot'+side,'cube',name)
 if name=='Messenger':
  profile=[(-1,-1),(1,-1),(1,-.28),(.05,-.03),(1,.22),(1,.68),(.1,1),(-1,.72)]
  verts=[(x,y,z) for y in [-1,1] for x,z in profile];n=len(profile)
  faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
  data=bpy.data.meshes.new('BrokenBladeGeometry');data.from_pydata(verts,[],faces);data.update()
  o=bpy.data.objects.new(name+'_blade',data);bpy.context.collection.objects.link(o);data.materials.append(mats['Metal']);parts['blade']=o
 else:parts['blade']=mesh(name+'_blade','cube','Metal')
 parts['guard']=mesh(name+'_guard','cube','Dark')
 if name=='Messenger':parts['sheath']=mesh(name+'_sheath','cube','Dark')
 if name!='Messenger':parts['hat']=mesh(name+'_hat','cone',name,radius1=.48,radius2=.08,depth=.12)
 else:parts['headband']=mesh(name+'_headband','cylinder','Dark')
 actors[name]=parts

def ktransform(o,f):
 for p in ['location','rotation_euler','scale']:o.keyframe_insert(p,frame=f)

def actor(name,f,x,y,face,lean=0,crouch=0,arms=None,stride=0,bladeangle=0,visible=True,yaw_override=None,lift=0,sheathed=False,blade_target=None):
 parts=actors[name]
 yaw=(.45 if name=='A' else -.29 if name=='B' else 0) if yaw_override is None else yaw_override
 def P(p):
  u,v=face*p[0],p[1]
  return Vector((x+u*math.cos(yaw)-v*math.sin(yaw),y+u*math.sin(yaw)+v*math.cos(yaw),p[2]+lift))
 hip=Vector((0,0,1.03-crouch));shoulder=Vector((lean,0,1.65-crouch));head=shoulder+Vector((lean*.15,0,.29))
 if name=='Main' and lean<-.15:head.x+=.35
 segment(parts['neck'],P(shoulder),P(head-Vector((0,0,.17))),.10,f)
 segment(parts['torso'],P(hip),P(shoulder),.24,f)
 parts['head'].location=P(head);parts['head'].scale=(.19,.18,.23);ktransform(parts['head'],f)
 parts['belt'].location=P(hip);parts['belt'].scale=(.25,.19,.19);ktransform(parts['belt'],f)
 if arms is None:arms=[(.42,-.23,1.42),(.72,-.2,1.42),(.22,.23,1.28),(.45,.2,1.15)]
 for side,el,wr,dy in [('L',arms[0],arms[1],-.23),('R',arms[2],arms[3],.23)]:
  segment(parts['upper'+side],P(shoulder+Vector((0,dy,0))),P(el),.085,f)
  segment(parts['fore'+side],P(el),P(wr),.075,f)
 for side,dy,s in [('L',-.13,stride),('R',.13,-stride)]:
  knee=(s*.3+lean*.4,dy,.58-crouch*.45);foot=(s*.55-.12,dy,.12)
  segment(parts['thigh'+side],P(hip+Vector((0,dy,0))),P(knee),.105,f)
  segment(parts['shin'+side],P(knee),P(foot),.09,f)
  o=parts['foot'+side];o.location=P((foot[0]+.1,dy,.08));o.scale=(.19,.105,.08);o.rotation_euler.z=yaw;ktransform(o,f)
 wrist=P(arms[1]);length=.68 if name=='Messenger' else .85
 direction=Vector((face*math.cos(bladeangle)*math.cos(yaw),face*math.cos(bladeangle)*math.sin(yaw),math.sin(bladeangle)))
 tip=wrist+direction*length
 if blade_target is not None:tip=Vector(blade_target);length=(tip-wrist).length;direction=(tip-wrist).normalized()
 if sheathed:
  wrist=P((.04,-.33,1.01));tip=P((-.12,-.33,.37));length=(tip-wrist).length;direction=(tip-wrist).normalized()
 if 'sheath' in parts:
  o=parts['sheath'];a=P((.03,-.35,.98));b=P((-.13,-.35,.34));segment(o,a,b,.048,f)
 o=parts['blade'];o.location=(wrist+tip)/2;o.rotation_mode='QUATERNION';o.rotation_quaternion=direction.to_track_quat('Z','Y');o.scale=(.038,.018,length/2)
 for prop in ['location','rotation_quaternion','scale']:o.keyframe_insert(prop,frame=f)
 o=parts['guard'];o.location=wrist;o.scale=(.035,.13,.035);ktransform(o,f)
 if 'hat' in parts:o=parts['hat'];o.location=P(head+Vector((0,0,.2)));ktransform(o,f)
 else:
  o=parts['headband'];o.location=P(head+Vector((0,0,.1)));o.scale=(.195,.185,.04);ktransform(o,f)
 for o in parts.values():
  o.hide_render=(not visible) or (o==parts.get('sheath') and not sheathed);o.keyframe_insert('hide_render',frame=f)

# Bake readable key poses at short intervals with linear interpolation.
shots=[(1,72),(73,108),(109,144),(145,192),(193,240),(241,276),(277,312),(313,336),(337,360)]
for shot,(start,end) in enumerate(shots,1):
 frames=range(start,end+1)
 for f in frames:
  t=(f-start)/max(1,end-start)
  mx,my=-.9,0;nx,ny=.85,.12;ml=nl=mc=nc=0;ms=ns=0;ma=na=None;mb=nb=0;nyaw=0;lift=0;target=None
  if shot==1:
   mx=-2.5+1.2*t;ml=.42;mc=.38;ms=math.sin(t*math.pi*5);nx=4
   ma=[(.15,-.23,1.08),(.47,-.22,.88),(-.25,.23,1.22),(-.4,.2,1.05)];mb=-.3
  elif shot==2:
   mx=-1.3;nx=-.8+1.65*t;ny=2.6*(1-t)+.12*t;nl=.22;ns=math.sin(t*math.pi*3)
   ma=[(.15,-.23,1.15),(.28,-.25,.93),(.05,.23,1.25),(.15,.25,1.0)]
   nyaw=math.atan2(-ny,mx-nx)-math.pi
   jump=max(0,min(1,(t-.14)/.72));lift=.7*math.sin(math.pi*jump)
   na=[(.35,-.23,1.45),(.65,-.2,1.43),(.15,.23,1.35),(.35,.23,1.3)]
  elif shot==3:
   mx=-1.05-.2*t;my=-.3-.45*math.sin(t*math.pi/2);ml=-.25;mc=.2
   nx=.95-.85*t;nl=.30;na=[(.55,-.23,1.5),(1.05,-.2,1.47),(.25,.23,1.35),(.48,.2,1.27)]
   target=(-1.85,.425,1.43) if f>=127 else None
  elif shot==4:
   mx=-.75;nx=.85
   ma=[(.35,-.23,1.38),(.68,-.2,1.38),(.25,.23,1.35),(.6,.12,1.42)];mb=.65-.2*t
   na=[(.32,-.23,1.4),(.62,-.284,1.35),(.25,.23,1.4),(.5,.15,1.45)];nb=.5-.1*t
  elif shot==5:
   mx=-.75+1.2*t;nx=.55+.65*t;ml=.4;nl=-.2*t;ms=.5;ns=-.4;nb=1.2
   na=[(.10,-.42,1.55),(.15,-.65,1.72),(.2,.23,1.32),(.45,.2,1.28)]
   ma=[(.37,-.55,1.45),(.59,-.85,1.55),(.35,.23,1.48),(.62,.2,1.5)];mb=.8
  elif shot==6:
   mx=.45;nx=1.2+.31*t;ny=.12+.15*t;nl=-.15-.35*t;nc=.12*t;nb=.75
   ma=[(.2,-.23,1.15),(.4,-.3,1.04),(.18,.23,1.25),(.28,.23,1.12)];mb=-.8
   na=[(.0,-.3,1.65),(.08,-.6,1.85),(-.15,.3,1.6),(-.1,.6,1.7)]
  elif shot==7:
   mx=.05-.85*t;nx=2.0;ny=1.55;nl=-.4;nc=.60
   ma=[(.38,-.25,1.35),(.73,-.55+.95*t,1.36),(.05,.25,1.3),(-.12,.25,1.15)];mb=.1;ms=-.5
  elif shot==8:
   my=-.6*t;mx=-.8;nx=2.0;ny=1.55;nl=-.4;nc=.60
   ma=[(.2,-.23,1.2),(.46,-.2,1.04),(.1,.23,1.25),(.3,.2,1.06)];mb=-.65
  else:
   my=-.6;mx=-.8;nx=2.0;ny=1.55;nl=-.4;nc=.60
   ma=[(.2,-.23,1.2),(.46,-.2,1.04),(.1,.23,1.25),(.3,.2,1.06)];mb=-.65
  actor('Messenger',f,mx,my,1,ml,mc,ma,ms,mb,sheathed=shot<=2)
  actor('Main',f,nx,ny,-1,nl,nc,na,ns,nb,visible=shot!=1 and not (shot==2 and t<.14),yaw_override=nyaw,lift=lift,blade_target=target)
  actor('A',f,-4,-2.4+.3*t if shot==9 else -2.4,1,arms=[(.25,-.23,1.18),(.50,-.2,1.1),(.2,.23,1.2),(.35,.25,1.0)],bladeangle=-.6,visible=shot==9 and f>=345)
  actor('B',f,-4.8,.9-.3*t if shot==9 else .9,1,arms=[(.25,-.23,1.18),(.50,-.2,1.1),(.2,.23,1.2),(.35,.25,1.0)],bladeangle=-.6,visible=shot==9 and f>=345)

def camera(label,start,end,pos1,target1,pos2=None,target2=None,lens=48):
 bpy.ops.object.camera_add();cam=bpy.context.object;cam.name=label;cam.data.lens=lens;cam.data.clip_end=120
 for f,pos,target in [(start,pos1,target1),(end,pos2 or pos1,target2 or target1)]:
  cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();ktransform(cam,f)
 marker=scene.timeline_markers.new(label,frame=start);marker.camera=cam
 return cam
camera('01A_TRACK',1,44,(-4,-4,1.4),(-2.4,0,1.2),(-2.7,-4,1.35),(-1.65,0,1.15),52)
camera('01B_FEET',45,72,(-1.9,-2,.5),(-1.6,0,.35),(-1.5,-2,.5),(-1.3,0,.35),60)
camera('02A_AMBUSH',73,90,(1,-4,2.6),(-.65,1.1,1.5),(.5,-4,2.4),(-.1,1,1.6),42)
camera('02B_THRUST',91,108,(-2,-2,2.15),(.03,1.36,1.75),(-1.2,-2.5,1.95),(.85,.12,1.62),38)
camera('03A_DODGE',109,126,(-.8,-3,1.75),(-1.2,-.5,1.4),(-1,-3,1.75),(-1.25,-.75,1.4),45)
camera('03B_BLADE',127,144,(-2.1,-1.6,1.75),(-1.5,.4,1.43),(-2,-1.4,1.7),(-1.65,.5,1.43),58)
camera('04_LOCK',145,192,(-.3,-2.8,1.7),(.0,-.18,1.5),(-.3,-2.05,1.65),(.05,-.18,1.5),65)
camera('05_SHOULDER',193,240,(-.1,-4.9,2.0),(.3,0,1.1),(.55,-4.8,2),(.65,0,1.15),48)
camera('06A_IMPACT',241,258,(-1,-3.9,.85),(1.35,.25,1.3),(-.7,-3.5,.85),(1.5,.3,1.3),46)
camera('06B_BACK',259,276,(3.8,-2,2.1),(1.8,.25,1.5),(3.5,-1.8,2),(1.8,.25,1.5),55)
camera('07_SLASH',277,312,(-1.5,-2.9,1.5),(-.05,0,1.35),(-2,-2.9,1.5),(-.6,0,1.35),52)
camera('08_HOLD',313,336,(-2.4,-4.7,1.85),(-.8,0,1.15),(-2.4,-5.3,1.85),(-.8,-.6,1.15),lens=58)
final_cam=camera('09_REVEAL',337,348,(2.1,-.6,1.94),(.03,-.8,.72),(2.1,-.6,1.94),(-.8,-.6,1.77),lens=54)
final_cam.keyframe_insert('location',frame=360);final_cam.keyframe_insert('rotation_euler',frame=360)
# Restrained handheld movement for chase and impact shots.
for label,first,last,amplitude in [('01A_TRACK',1,44,.012),('05_SHOULDER',193,240,.009)]:
 cam=bpy.data.objects[label]
 values=[]
 for f in range(first,last+1):
  scene.frame_set(f);values.append((f,cam.location.copy(),cam.rotation_euler.copy()))
 for f,loc,rot in values:
  cam.location=loc+Vector((amplitude*math.sin(f*.71),0,amplitude*math.sin(f*.53)))
  cam.rotation_euler=rot;cam.rotation_euler.z+=amplitude*.4*math.sin(f*.65);ktransform(cam,f)
for obj in bpy.data.objects:
 if obj.animation_data and obj.animation_data.action:
  for fc in obj.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='CONSTANT' if fc.data_path=='hide_render' else 'LINEAR'
scene.frame_set(1)
scene.camera=bpy.data.objects['01A_TRACK']
bpy.ops.wm.save_as_mainfile(filepath='/workspace/outputs/broken_blade_previs_v2.blend')
import sys
if '--' in sys.argv:
 args=sys.argv[sys.argv.index('--')+1:]
 if args and args[0]=='preview':
  for f in [22,84,101,118,136,168,220,270,299,325,352]:
   scene.frame_set(f);scene.render.filepath=str(OUT/f'preview_{f:03}.png');bpy.ops.render.render(write_still=True)
 elif args and args[0]=='render':bpy.ops.render.render(animation=True)

# 断刃信使：竹林死斗 — V2 修订版

视频：broken_blade_previs_v2.mp4。可编辑场景：broken_blade_previs_v2.blend。
1920×1080，16:9，24fps，360 帧，15 秒，MP4 / H.264；无声。

## 本次修改

- 第一镜信使双手空手疾行；带缺口的断刀和几何刀鞘别在腰侧。
- 主力从信使自身左侧（信使前进方向为 +X，左侧为 +Y）的竹林跳出，有离地和落地关键帧；此阶段信使仍未拔刀。
- 闪避时退至掩护竹附近；另用相邻竹干表现刺尖擦过后的击竹。
- 调整撞竹位置、后仰姿势、刀具和退步路径，检查人物、刀具与竹干/竹节的表面相交；武器对躯干、头部、腿部及手臂也作逐帧相交检查。
- 最后一镜从断刀低位上摇到信使正面。A、B 在其后方，至最后一镜才显露。镜头正对信使面部朝向，不再侧拍。
- 人物配色保持：信使橙，主力深蓝，A 紫，B 青。

## 时间轴

新上传文字脚本的五段时间（0–3、3–6、6–10、10–13、13–15 秒）与分镜图的细分时间不同。本版采用文字脚本的五段时间，保留图中的九镜顺序和主体动作。第一镜持刀方式按用户明确修正（空手、刀别腰间），优先于附件“右手断刃压在腰侧”的描述。

| 镜头 | 起止秒 | 帧号（含首尾） | 运镜 |
|---|---|---|---|
| 01 贴竹疾行 | 0–3 | 1–72 | 低机位跟拍 → 脚步特写 |
| 02 左侧伏击 | 3–4.5 | 73–108 | 侧近景跳出 → 刺尖推进 |
| 03 贴竹闪避 | 4.5–6 | 109–144 | 跟随闪避 → 刀击竹干特写 |
| 04 断刃锁刺 | 6–8 | 145–192 | 缺口锁刃特写缓推 |
| 05 撞身破力 | 8–10 | 193–240 | 双人中景轻手持 |
| 06 背砸青竹 | 10–11.5 | 241–276 | 低机位缓慢动作 → 背部接触近景 |
| 07 横削撤步 | 11.5–13 | 277–312 | 近景横削并后撤 |
| 08 收势屏息 | 13–14 | 313–336 | 中景跟随两步后撤 |
| 09 杀机四伏 | 14–15 | 337–360 | 断刀上摇 → 信使正面；A、B 在后方显露 |

## 简化与尚未明确的信息

独立文字脚本现已收到。没有口播录音、音乐和音效素材，本版仍为无声镜头验证。
不制作五官、服装、写实细节、血液、火花、竹叶粒子或复杂模拟；抬眼用头部朝向和正面机位表达。
场地与人物实际尺寸未指定，采用一致相对比例。刀具锁定、肩撞和撞竹采用关键姿势与几何接触近似。
逐帧相交检测针对当前网格的表面；不代表正式物理接触模拟。

## 重建

```bash
XDG_CONFIG_HOME=/workspace/outputs/previs_v2/config XDG_CACHE_HOME=/workspace/outputs/previs_v2/cache blender -b -t 4 --python-exit-code 1 --python /workspace/outputs/previs_v2/build.py
XDG_CONFIG_HOME=/workspace/outputs/previs_v2/config XDG_CACHE_HOME=/workspace/outputs/previs_v2/cache blender -b /workspace/outputs/broken_blade_previs_v2.blend -t 4 -a
ffmpeg -y -framerate 24 -start_number 1 -i /workspace/outputs/previs_v2/frames/frame_%04d.png -vf 'ass=/workspace/outputs/previs_v2/labels.ass' -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -frames:v 360 -movflags +faststart /workspace/outputs/broken_blade_previs_v2.mp4
```

## 验证记录

360 帧逐帧检查：人物/刀具与竹干、竹节的网格表面相交为 0；刀具与对手身体、手臂的网格表面相交为 0。首镜腰间刀、左侧起跳和末镜正面/后方 A、B 的位置检查均通过。A、B 首次可见于第 345 帧（14.333 秒），只在最后一镜出现。

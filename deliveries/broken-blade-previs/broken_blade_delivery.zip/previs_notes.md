# 断刃信使：竹林死斗 — 白模预演

视频：broken_blade_previs.mp4。可编辑场景：broken_blade_previs.blend。
规格：1920×1080，16:9，24fps，360 帧，15 秒，MP4 / H.264；无声。
工作台渲染，低精度几何人形，线性关键帧；未使用复杂模拟。

| 人物 | 纯色 | 出场 |
|---|---|---|
| 断刃信使 | 橙 | 全片 |
| 主力黑衣死士 | 深蓝 | 镜头 02 首次出场，承担 02–06 的攻击与交锋 |
| 伏击者 A | 紫 | 仅镜头 09 |
| 伏击者 B | 青 | 仅镜头 09 |

| 镜头 | 起止秒 | 帧号（含首尾） | 运镜 |
|---|---|---|---|
| 01 贴竹疾行 | 0–2 | 1–48 | 低机位跟拍 → 脚步特写 |
| 02 伏击爆发 | 2–4 | 49–96 | 中近景 → 突刺近景短推 |
| 03 贴竹闪避 | 4–6 | 97–144 | 近景跟随 → 刀击竹干特写 |
| 04 断刃锁刺 | 6–8 | 145–192 | 武器特写缓推 |
| 05 撞身破力 | 8–10 | 193–240 | 双人中景平移跟随 |
| 06 背砸青竹 | 10–12 | 241–288 | 低机位缓慢动作 → 接触近景 |
| 07 横削撤步 | 12–13 | 289–312 | 近景跟随后撤 |
| 08 收势屏息 | 13–14 | 313–336 | 中景定机位 |
| 09 杀机四伏 | 14–15 | 337–360 | 缓摇并后移，显露伏击 A、B |

## 尚未明确及预演简化

未收到独立脚本、口播和音频附件：时长依据已确认的分镜时间轴，无音乐或音效。
人物具体身高、竹林实际尺寸与刀具尺寸未给定，使用相对比例验证。
脸部、服装、血液、火花、碎屑与落叶不制作；眼神由头部朝向和机位代替。
结尾两名伏击者在镜头 09 首次显露；主力撞竹后低姿退至画面右侧。
精确动作表演及刀具接触仍须以正式动作素材或拍摄排练校准。本版本验证基础站位、方向、层次与节奏。

## 重建和导出

在当前环境中执行：

```bash
XDG_CONFIG_HOME=/workspace/outputs/previs/config XDG_CACHE_HOME=/workspace/outputs/previs/cache blender -b -t 4 --python-exit-code 1 --python /workspace/outputs/previs/build.py
XDG_CONFIG_HOME=/workspace/outputs/previs/config XDG_CACHE_HOME=/workspace/outputs/previs/cache blender -b /workspace/outputs/broken_blade_previs.blend -t 4 -a
ffmpeg -y -framerate 24 -start_number 1 -i /workspace/outputs/previs/frames/frame_%04d.png -vf 'ass=/workspace/outputs/previs/labels.ass' -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -frames:v 360 -movflags +faststart /workspace/outputs/broken_blade_previs.mp4
```

输出目录位于仓库外，未修改仓库文件。通过本机 Blender 后台脚本制作；当前会话没有可调用的 Blender MCP 工具。
